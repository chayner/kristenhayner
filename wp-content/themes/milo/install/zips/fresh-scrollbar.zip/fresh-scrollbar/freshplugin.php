<?php
/*
Plugin Name: Fresh Scrollbar
Plugin URI: http://freshface.net
Description: The fastest and most native customization of your Scrollbar powered by modern CSS3
Version: 1.0.0
Author: FRESHFACE
Author URI: http://freshface.net
Dependency: fresh-framework
*/