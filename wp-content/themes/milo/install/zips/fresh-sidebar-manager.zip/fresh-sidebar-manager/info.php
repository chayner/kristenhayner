<?php

$info = array();
$info['plugin-name'] = 'p-fresh-sidebar-manager';
$info['plugin-version'] = '1.1.8';